 function x = alu (A , b )
     % x = alu (A , b )
     % Risolve il sistemma lineare Ax = b con A matrice non singolare , con il
     % metodo di fattorizzazione LU
     % Input :
     % A: Matrice dei coefficienti
     % b: Vettore dei termini noti
     % Output :
     % x: Vettore soluzione
     %
     % Val: 10/10/2024
     [m,n]=size(A);
     if m~=n
        error('Matrice dei coefficienti errata');
     end
     for i=1:n
        if A(i,i)==0
            error('matrice non fattorizzabile LU');
        end
        A(i+1:n,i)=A(i+1:n,i)/A(i,i);
        A(i+1:n,i+1:n)=A(i+1:n,i+1:n)-A(i+1:n,i)*A(i,i+1:n);
     end
     x=b(:);  %vettore colonna
     for j=1:n
        for i=j+1:n
            x(i)=x(i)-A(i,j)*x(j);
        end
     end
     for i=n:-1:1  %i che va da n a 1 scalando di -1 per ogni iterazione
        x(i)=x(i)/A(i,i);
        x(1:i-1)=x(1:i-1)-x(i)*A(1:i-1,i);
     end
 end