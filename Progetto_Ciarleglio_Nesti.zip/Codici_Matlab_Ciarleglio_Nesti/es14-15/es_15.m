format long
x0 = zeros(50, 1); %vettore iniziale per newton
x=linspace(1,50,50); %vettore riga di 50 punti equidistanti tra loro tra 1 e 50
f=@funEs15;

%Script per toll 10^-3
tol=1e-3;
[Soluzione1, Iterazioni1] = newtonEs15(f, x0, tol);
%creazione grafico 1
figure(1);  
plot(x,Soluzione1,'ko-','MarkerSize',3);
hold on;
title('Grafico della soluzione con tolleranza 1e-3');
xlabel('Indice');
ylabel('Valore');

%Script per toll 10^-8
tol=1e-8;
[Soluzione2, Iterazioni2] = newtonEs15(f, x0, tol);
%creazione grafico 2
figure(2);
plot(x,Soluzione2,'ko-','MarkerSize',3);
hold on;
title('Grafico della soluzione con tolleranza 1e-8');
xlabel('Indice');
ylabel('Valore');

%Script per toll 10^-13
tol=1e-13;
[Soluzione3, Iterazioni3] = newtonEs15(f, x0, tol);
%creazione grafico 3
figure(3);
hold on;
plot(x,Soluzione2,'ko-','MarkerSize',3);
title('Grafico della soluzione con tolleranza 1e-13');
xlabel('Indice');
ylabel('Valore');


fprintf('\nSoluzioni:\n'); 
tabellaSoluzioni = table(Soluzione1,Soluzione2, Soluzione3);
disp(tabellaSoluzioni);
numeroIterazioni=table(Iterazioni1, Iterazioni2, Iterazioni3);
fprintf('\nNumero di iterazioni: \n');
disp(numeroIterazioni);
fprintf('\n\n');