function [f, jacobian] = fun(x)
    % [f, jacobian] = fun(x)
    %
    % Funzione che restituisce il sistema di equazioni non lineari e la
    % matrice Jacobiana calcolata nel punto x.
    %
    % Input:
    % x: Vettore delle variabili
    %
    % Output:
    % f: Vettore funzione f(x) = 0
    % jacobian: Matrice Jacobiana di f rispetto a x
    %
    % Val: 10/10/2024
    
    f = [x(1)^2 + x(2)^2 - 1;  % Prima equazione: x1^2 + x2^2 = 1
         x(1) - x(2)^2];        % Seconda equazione: x1 = x2^2
    
    jacobian = [2*x(1), 2*x(2);  % Derivate parziali rispetto a x1 e x2
                1, -2*x(2)];
end
