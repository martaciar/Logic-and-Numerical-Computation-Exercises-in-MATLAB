function [fun, jacobian] = funEs15(x)
     %
     % [fun, jacobian] = fun15(x)
     % Restituisce il sistema di equazioni e la matrice Jacobiana del sistema
     % calcolate nelle ascisse x
     %
     % Input:
     % x: Vettore delle ascisse
     %
     % Output:
     % fun: Sistema di m equazioni in n incognite della forma
     % fi(x(1),...,x(n))=0 con i=1,...,m dove fi é l' i-esima funzione
     % componente di fun(x) calcolata nelle ascisse
     % jacobian: Matrice jacobiana del sistema fun calcolata nelle ascisse
     %
     % Val: 10/10/2024
     
     n=length(x);
     x=x(:);  %trasformazione in vettore colonna
     alpha = 2;
     beta =-1.1;
     Q = 4 * eye(n);
     Q=Q+diag(ones(n-1,1),1)+diag(ones(n-1,1),-1);
     e = ones(n, 1);
     grad =@(x) Q * x- alpha * e.*sin(alpha * x)-beta * e.* exp(-x);
     fun=grad(x);
     hess =@(x) Q-alpha^2 * diag(e.*cos(alpha*x))+beta*diag(e.*exp(-x));
     jacobian=hess(x);
 end