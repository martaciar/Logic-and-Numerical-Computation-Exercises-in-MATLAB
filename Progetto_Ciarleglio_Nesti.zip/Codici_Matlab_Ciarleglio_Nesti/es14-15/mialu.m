function x=mialu(A, b)
    % x=mialu(A, b)
    %
    % Funzione che risolve il sistema lineare Ax = b tramite fattorizzazione LU con pivoting parziale.
    %
    % Input:
    % A = Matrice quadrata dei coefficienti
    % b = Vettore dei termini noti
    %
    % Output:
    % x = Soluzione del sistema Ax = b
    %
    % Val: 01/10/2024
    
    [m,n]=size(A);
    if n~=m
        error('La matrice A deve essere quadrata.');
    end
    if n~=length(b)
        error('Dimensione errata del vettore b.');
    end
    
    % Tolleranza per verificare la singolarità
    tol=n*eps*norm(A,inf);
    
    % Vettore per le permutazioni
    p=1:n;
    
    % Fattorizzazione LU con pivoting parziale
    for i=1:n-1
        % Pivoting: trova l'elemento massimo nella colonna corrente
        [maxval,k]=max(abs(A(i:n,i)));
        if maxval<=tol
            error('La matrice è singolare o mal condizionata.');
        end
        k=k+i-1;
        
        % Scambio di righe se necessario
        if k~=i
            A([i,k],:)=A([k,i],:);
            p([i,k])=p([k,i]);
        end
        
        % Eliminazione gaussiana
        A(i+1:n,i)=A(i+1:n,i)/A(i,i);
        A(i+1:n,i+1:n)=A(i+1:n,i+1:n)-A(i+1:n, i)*A(i, i+1:n);
    end
    
    % Risoluzione del sistema
    x=b(p);
    x=x(:);  % Assicura che x sia un vettore colonna
    
    % Risoluzione del sistema triangolare inferiore L*y = Pb
    for i=2:n
        x(i:n)=x(i:n)-A(i:n,i-1)*x(i-1);
    end
    
    % Risoluzione del sistema triangolare superiore U*x = y
    for i=n:-1:1
        x(i)=x(i)/A(i, i);
        x(1:i-1)=x(1:i-1)-A(1:i-1, i)*x(i);
    end
end
