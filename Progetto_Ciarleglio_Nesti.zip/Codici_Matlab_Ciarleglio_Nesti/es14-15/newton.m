function [x,nit] = newton(fun,x0,tol,maxit)
    %   [x,nit] = newton(fun,x0,tol,maxit)
    %   Funzione che risolve un sistema non lineare tramite metodo metodo di
    %   newton
    %   Input:
    %   fun = Function handle che restituisce [f(x), J(x)] dove:
    %           f(x) è il sistema di equazioni e J(x) è il jacobiano
    %   x0 = Vettore iniziale di valori
    %   tol = Tolleranza per il criterio di arresto 
    %   maxit = Numero massimo di iterazioni (default: 1000)
    %   Output:
    %   x=vettore soluzione del sistema
    %   nit= numero iterazioni svolte
    %
    %   Val: 06/10/2024
    
    %controllo argomenti
    if nargin<2
    error('Numero di argomenti in ingresso non valido');
    end
    if nargin<3 || isempty(tol)
        tol = eps * length(x0);
    end
    if nargin <4 || isempty(maxit)
        maxit = 1000;
    end
    if tol <= 0
        error('Tolleranza non valida');
    end
    if maxit <= 0
        error('Numero di iterazioni non valido');
    end
    %esecuzione metodo newton per sistemi non lineari
    for nit=1:maxit
        x0=x;
        [b,A]=feval(fun, x0);
        b=-b;
        x = x0 + mialu(A,b);
        %controllo condizione di uscita per raggiungimento tolleranza
        if norm((x - x0)./(1 + abs(x0))) <= tol
            break;
        end
    end
    if norm((x - x0)./(1 + abs(x0))) > tol
        disp('Approssimazione non soddisfacente in relazione alla tolleranza');
    end
end