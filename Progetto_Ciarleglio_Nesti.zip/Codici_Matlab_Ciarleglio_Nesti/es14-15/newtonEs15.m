 function [x,nit] = newtonEs15(fun,x0,tol,maxIt)
     %
     % [x,nit] = newtonEs15(fun,x0,tol,maxit)
     % Funzione che implementa il metodo di newton per la risoluzione di
     % sistemi di equazioni non lineari modificato per il caso specifico
     %
     % Input:
     % fun: Funzione nella forma [f,jacobian]=fun(x)
     % x0: Vettore dei valori iniziali
     % tol: Tolleranza con criterio d'arresto ||(Xn+1- Xn)./(1 + |Xn|)|| <= tol
     % maxit: Numero massimo di iterazioni
     %
     % Output:
     % x: Soluzione del sistema
     % nit: Numero di iterazioni eseguite nel trovare la soluzione
     %
     % Val: 10/10/2024
     if nargin < 3
        tol = length(x0) * eps;
     end
     if nargin < 4
        maxIt = 1000;
     end
     if tol <= 0
        error('Tolleranza non valida'); 
     end
     if maxIt <= 0
        error('Numero di iterazioni non valido'); 
     end
     x=x0;
     x0=x0(:);   %trasformazione in vettore colonna
     x=x(:);
     for i=1:maxIt
        x0=x;  %aggiornamento x0 per nuova iterazione
        [b,A]=feval(fun, x0);
        b=-b;
        x = x0 + alu(A,b); %Risoluzione del sistema Ax=b usando A e b appena calcolate
        if norm((x- x0)./(1 + abs(x0))) <= tol %criterio d'arresto
            break;
        end
     end
     nit = i;
     if norm((x- x0)./(1 + abs(x0))) > tol
        disp('Tolleranza non raggiunta');
     end
 end