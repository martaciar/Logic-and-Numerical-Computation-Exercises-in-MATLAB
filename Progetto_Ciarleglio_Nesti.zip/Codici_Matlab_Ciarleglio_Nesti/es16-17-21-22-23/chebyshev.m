function x = chebyshev(n, a, b)
    % x = cheby(n, a, b)
    %
    % Funzione che calcola le n+1 ascisse di Chebyshev sull'intervallo [a, b]
    %
    % Input:
    % n: Grado del polinomio interpolante
    % [a, b]: Intervallo in cui vengono calcolate le ascisse
    %
    % Output:
    % x: Ascisse di Chebyshev 
    %
    % Val: 20/10/2024
    if nargin < 3
        error('Argomenti insufficienti');
    end
    if a >= b || n <= 0
        error('Argomenti erratti.');
    end
    x = (a+b)/2 + ((b-a)/2) * cos((2*(n:-1:0) + 1)/((2*(n+1)))*pi);
end