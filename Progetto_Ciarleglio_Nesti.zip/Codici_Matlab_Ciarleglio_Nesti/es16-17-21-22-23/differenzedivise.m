function dd = differenzedivise(x, y)
    % dd = differenzedivise(x, y)
    % 
    % Calcola le differenze divise per il polinomio interpolante in forma di
    % Newton sulle coppie (x, y)
    %
    % Input:
    % x: Vettore delle ascisse
    % y: Vettore delle ordinate
    % Output:
    % dd: Vettore delle differenze divise
    %
    % Val: 14/10/2024
    
    n = length(x);
    if length(y) ~= n
        error('Dati errati');
    end
    n = n-1;
    dd = y;
    for j=1:n
        for i = n+1:-1:j+1
            dd(i) = (dd(i) - dd(i-1))/(x(i) - x(i-j));
        end
    end
end