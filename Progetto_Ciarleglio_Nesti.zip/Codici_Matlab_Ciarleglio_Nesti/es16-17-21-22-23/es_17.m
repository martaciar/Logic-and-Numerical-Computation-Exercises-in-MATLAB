f=@(x) cos(2*x)/2;
x=0:pi/6:4*pi;
y=f(x); 
xq = 0:0.05:4*pi;
yqs = spline(x,y,xq);
yq=newton(x, y, xq);
figure(1);
plot(x,y,'ko','LineWidth',2,'MarkerSize',2)
hold on
plot(xq,yqs,'LineWidth',2)
title('cos(2x)/2 con funzione spline di matlab')
xlabel('x');
ylabel('f(x)');
grid on;
figure(2);
plot(x,y,'ko','LineWidth',2,'MarkerSize',2)
hold on
plot(xq,yq,'LineWidth',2)
title('cos(2x)/2 con funzione di Newton')
xlabel('x');
ylabel('f(x)');
grid on;