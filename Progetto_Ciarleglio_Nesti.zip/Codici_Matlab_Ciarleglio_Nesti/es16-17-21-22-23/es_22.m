a=-5;
b=8;
x=1:100;
L0=zeros([1,100]);
L1=zeros([1,100]);
for i=1:100
    L0(1,i)=lebesgue(a, b, i, 0);
    L1(1,i)=lebesgue(a, b, i, 1);
end
figure(1)
plot(x, L0,'ko','LineWidth',2,'MarkerSize',2);
hold on;
title('Costante di Lebesgue nell intervallo [-5,8]');
xlabel('Grado del polinomio');
ylabel('Costante di Lebesgue');
figure(2);
plot(x, L1,'ko','LineWidth',2,'MarkerSize',2);
hold on;
title('Costante di Lebesgue nell intervallo [-5,8] con ascisse di Chebyshev');
xlabel('Grado del polinomio');
ylabel('Costante di Lebesgue');
a=0;
b=1;
L2=zeros([1,100]);
L3=zeros([1,100]);
for i=1:100
    L2(1,i)=lebesgue(a, b, i, 0);
    L3(1,i)=lebesgue(a, b, i, 1);
end
figure(3)
plot(x,L2,'ko','LineWidth',2,'MarkerSize',2);
hold on;
title('Costante di Lebesgue nell intervallo [0,1]');
xlabel('Grado del polinomio');
ylabel('Costante di Lebesgue');
figure(4);
plot(x, L3,'ko','LineWidth',2,'MarkerSize',2);
hold on;
title('Costante di Lebesgue nell intervallo [0,1] con ascisse di Chebyshev');
xlabel('Grado del polinomio');
ylabel('Costante di Lebesgue');