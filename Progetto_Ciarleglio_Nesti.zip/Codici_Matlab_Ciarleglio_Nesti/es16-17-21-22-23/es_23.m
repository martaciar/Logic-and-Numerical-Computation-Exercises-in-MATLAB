xq = linspace(-5, 5, 10001);
f=@(x) 1./(1+x.^2);
yf = f(xq);
nn = 2:2:100;

errLag = zeros(length(nn), length(xq));
errNew= zeros(length(nn), length(xq));

for i = 1:length(nn)
    x= chebyshev(nn(i), -5, 5);
    y = f(x);
    yl = lagrange(x, y, xq);
    yn = newton(x, y, xq);
    errLag(i, :) = norm(yf - yl, inf);
    errNew(i, :) = norm(yf - yn, inf);
end
figure(1);
semilogy(nn, max(errLag, [], 2));
hold on;
xlabel('Grado del polinomio interpolante');
ylabel('Errore di interpolazione in scala logaritmica');
title('Errore di interpolazione utilizzando ascisse di Chebyshev con Lagrange');
figure(2);
semilogy(nn, max(errNew, [], 2));
hold on;
xlabel('Grado del polinomio interpolante');
ylabel('Errore di interpolazione in scala logaritmica');
title('Errore di interpolazione utilizzando ascisse di Chebyshev con Newton');