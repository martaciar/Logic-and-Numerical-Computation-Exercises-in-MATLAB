function L = lagBase(XQ, X, i)
    % L = lagbase(XQ, X, i)
    % Funzione che calcola il polinomio di base di Lagrange
    %
    % Input:
    % XQ: Vettore in cui calcolare il polinomio
    % X: Vettore ascisse
    % i: Posizione nel vettore
    %
    % Output:
    % L: Polinomio di base di Lagrange
    %
    % Val: 13/10/2024
    L = ones(size(XQ)); %inizializza il polinomio a 1
    n = length(X);
    yi = X(i); %ascissa i-esima
    X = X([1:i-1, i+1:n]); %esclude ascissa i-esima
    for k=1:(n-1)
        L = L.*(XQ- X(k))/(yi- X(k));
    end
end