function YQ = lagrange(X,Y,XQ)
    % YQ = lagrange(X,Y,XQ)
    % Funzione che calcola il polinomio interpolante in forma di Lagrange
    %
    % Input:
    % X: Ascisse del problema
    % Y: Valori della funzione calcolate sulle ascisse X
    % XQ: Vettore delle ascisse sulle quali calcolare i punti di interpolazione
    % del polinomio
    %
    % Output:
    % YQ: Punti interpolanti del polinomio in forma di Lagrange
    %
    % Val: 13/10/2024
    if nargin<3
        error('Numero di argomenti insufficiente');
    end
    if length(X) ~= length(Y) || length(X) <= 0
        error('Dimensione dei vettori X e Y incorretti');
    end
    if length(unique(X)) ~= length(X)
        error('Le ascisse non sono distinte');
    end
    YQ = zeros(size(XQ));
    for i=1:length(X)
        YQ = YQ + Y(i) * lagBase(XQ, X, i); %somma dei termini pesati dalle basi di lagrange
    end
end