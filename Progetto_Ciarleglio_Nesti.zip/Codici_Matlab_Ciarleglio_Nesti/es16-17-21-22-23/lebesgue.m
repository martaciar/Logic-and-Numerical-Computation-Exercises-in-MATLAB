function ll = lebesgue(a, b, nn, type)
    % ll=lebesgue(a, b, nn, type)
    % 
    % Funzione che approssima la costante di Lebesgue per l'interpolazione 
    % polinomiale sull'intervallo [a,b] per i polinomi con grado 
    % specificato nel vettore nn. Utilizza ascisse equidistanti, se 
    % type=0, o di Chebyshev, se type=1.
    %
    % Input:
    % a, b: Estremi dell'intervallo 
    % nn: Grado del polinomio
    % type: Variabile impostata a 0 per ascisse equidistanti sull'
    %       intervallo [a,b] o a 1 per le ascisse di Chebyshev
    % 
    % Output:
    % ll: Costante di Lebesgue
    %
    % Val:21/10/2024

    if nargin<4
        error('Argomenti insufficienti');
    end
    if type>1||type<0
        error('Tipo inserito non corretto.');
    end
    if(a>=b)
        error('Intervallo [a,b] inserito non corretto.')
    end
    if nn<1
        error('Grado del polinomio nn inserito non corretto')
    end
    if type==1
        x = chebyshev(nn, a, b);
    else
        x = linspace(a, b, nn+1);
    end
    n_punti=10001;
    xq = linspace(a, b, n_punti);
    L = zeros(n_punti, nn+1);
    for i = 1:nn+1
        L(:,i) = lagBase(xq, x, i);
    end

    funLeb = sum(abs(L), 2);
    ll = max(funLeb);
end
