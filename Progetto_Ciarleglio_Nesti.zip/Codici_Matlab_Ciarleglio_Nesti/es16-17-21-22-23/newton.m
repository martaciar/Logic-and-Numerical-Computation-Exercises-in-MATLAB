function YQ = newton(X, Y, XQ)
    % YQ = newton(X, Y, XQ)
    %
    % Funzione che calcola il polinomio interpolante in forma di Newton
    %
    % Input:
    % X: Ascisse del problema
    % Y: Valori della funzione calcolate sulle ascisse X
    % XQ: Vettore delle ascisse sulle quali calcolare i punti di interpolazione
    %     del polinomio
    %
    % Output:
    % YQ: Punti interpolanti del polinomio in forma di Newton
    %
    % Val: 14/10/2024
    if nargin<3 
        error('Numero di argomenti insufficiente');
    end
    if length(X) ~= length(Y) || length(X) <= 0
        error('Dati in ingresso dei vettori X e Y incorretti.');
    end
    if length(unique(X)) ~= length(X)
        error('Le ascisse non sono distinte');
    end
    diffdiv = differenzedivise(X, Y);
    n = length(diffdiv) - 1;
    YQ = diffdiv(n+1) * ones(size(XQ));
    for i = n:-1:1
        YQ = YQ.*(XQ - X(i)) + diffdiv(i);
    end
end