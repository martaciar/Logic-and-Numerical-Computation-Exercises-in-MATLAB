 function diffDiv = diffDivHermite(X, Y)
     % diffdiv = diffDivHermite(X, Y)
     %
     % Calcola le differenze divise per il polinomio interpolante in forma di
     % Hermite sulle coppie (xi, fi)
     %
     % Input:
     % X: Vettore delle ascisse
     % Y: Vettore delle ordinate e delle derivate della forma [f(0) f'(0)
     % ...f(n) f'(n)]
     %
     % Output:
     % diffDiv: Vettore delle differenze divise di Hermite
     %
     % Val: 17/10/2024
     n = length(X)-1;
     diffDiv = Y;
     for i = (2*n+1):-2:3 %da 2n+1 a 3 scalando di -2 (tratta solo gli indici dispari, cioè le f(x_i))
         %[f(x_i)-f(x_(i-1))]/[x_i-x_(i-1)]
        diffDiv(i) = (diffDiv(i)-diffDiv(i-2))/(X((i+1)/2)-X((i-1)/2));
     end
     for j = 2:2*n+1 %da 2 a 2n+1
        for i = (2*n+2):-1:j+1 %da 2n+2 a j+1 scalando di -1
            diffDiv(i) = (diffDiv(i)-diffDiv(i-1))/(X(ceil(i/2))-X(ceil((i-j)/2)));
        end
     end
 end