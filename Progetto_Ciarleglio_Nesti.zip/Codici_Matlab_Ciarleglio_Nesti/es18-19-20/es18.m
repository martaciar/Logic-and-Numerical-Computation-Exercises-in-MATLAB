% Definizione della nuova funzione e della sua derivata
f = @(x) exp(-x) .* sin(2 * x); % Funzione
f1 = @(x) -exp(-x) .* (2 * cos(2 * x) + sin(2 * x)); % Derivata

% Creazione del vettore delle ascisse x
x = 0:pi/6:4*pi; % Intervallo da 0 a 4π con passo di π/6

% Calcolo dei valori y della funzione e della derivata
y = f(x); 
y1 = f1(x);

% Intervallo di interpolazione per il grafico
xq = 0:0.05:4*pi; % Intervallo di query con passo di 0.05

% Interpolazione con spline
yqs = spline(x, y, xq);

% Interpolazione con il metodo di Hermite
yq = hermite(x, y, y1, xq);

% Grafico della funzione originale e dell'interpolazione spline
figure(1);
plot(x, y, 'ko', 'LineWidth', 2, 'MarkerSize', 2); % Punti originali
hold on;
plot(xq, yqs, 'LineWidth', 2); % Interpolazione spline
title('f(x) = e^{-x} * sin(2x) con funzione spline di MATLAB');
xlabel('x');
ylabel('f(x)');
grid on;

% Grafico della funzione originale e dell'interpolazione di Hermite
figure(2);
plot(x, y, 'ko', 'LineWidth', 2, 'MarkerSize', 2); % Punti originali
hold on;
plot(xq, yq, 'LineWidth', 2); % Interpolazione di Hermite
title('f(x) = e^{-x} * sin(2x) con funzione di Hermite');
xlabel('x');
ylabel('f(x)');
grid on;
