x=[0,2.5,5];
f=@(x) exp(x/2+(exp(-x))); %f
y=f(x);
f1=@(x) 0.5.*(exp(exp(-x)+0.5*x)-2.*exp  (-x).*exp(exp(-x)+0.5.*x)); %f'
y1=f1(x);
xq = 0:0.001:5;  % Ascisse dense per il calcolo e la visualizzazione del polinomio
[dq,yq]=hermiteHorner(x, y, y1, xq);

figure(1);
plot(x,y,'ko','LineWidth',2,'MarkerSize',2)
hold on
fplot (f, [0,5],'LineWidth', 2);
title('Funzione interpolanda')
xlabel('x');
ylabel('f(x)');
grid on;

figure(2);
plot(x,y,'ko','LineWidth',2,'MarkerSize',2);
hold on
plot(xq,yq,'LineWidth',2);
title('Polinomio interpolante')
xlabel('x');
ylabel('p(x)');
grid on;

figure(3);
plot(x,y1,'ko','LineWidth',2,'MarkerSize',2);
hold on
fplot (f1, [0,5],'LineWidth', 2);
title('Derivata prima funzione interpolanda')
xlabel('x');
ylabel("f'(x)");
grid on;

figure(4);
plot(x,y1,'ko','LineWidth',2,'MarkerSize',2);
hold on
plot (xq, dq,'LineWidth', 2);
title('Derivata prima polinomio interpolante')
xlabel('x');
ylabel("p'(x)");
grid on;