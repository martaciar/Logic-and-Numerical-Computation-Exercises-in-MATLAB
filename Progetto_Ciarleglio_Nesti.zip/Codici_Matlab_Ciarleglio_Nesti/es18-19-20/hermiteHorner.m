function [derivativeValues,yy] = hermiteHorner(xi, fi, f1i, xx)
 %
 % [yy,DQ] = hermiteHorner(xi, fi, f1i, xx)
 %
 % Funzione che calcola il polinomio interpolante in forma di Hermite
 % usando i valori di fi e f1i calcolati sulle ascisse xi per trovare i
 % valori interpolanti yy sui punti xx
 %
 % Input:
 % xi: Ascisse del problema
 % fi: Valori della funzione calcolate sulle ascisse xi
 % f1i: Valori della derivata della funzione calcolate sulle ascisse xi
 % xx: Vettore delle ascisse sulle quali calcolare i punti di interpolazione
 % del polinomio
 %
 % Output:
 % derivativeValues: Punti interpolanti della derivata del polinomio in 
 % forma hermite
 % yy: Punti interpolanti del polinomio in forma di Hermite
 %
 if nargin < 4
    error('Argomenti insufficienti');
 end
 if length(fi) ~= length(xi) || length(xi) <= 0 || length(xi) ~= length(f1i)
    error('Lunghezze dei vettori xi, fi e f1i incorrette ');
 end
 if length(unique(xi)) ~= length(xi)
    error('Le ascisse non sono distinte');
 end
 fi = repelem(fi, 2);%raddoppio le occorrenze di ogni elemento su fi
 for i = 1:length(f1i)
    fi(i*2) = f1i(i); %sostituzione della seconda occorrenza con valore della derivata
 end
 diffDiv = diffDivHermite(xi, fi); %calcolo vettore differenze divise
 n = length(diffDiv)-1;
 yy = diffDiv(n+1) * ones(size(xx));
 derivativeValues = zeros(size(xx));  % Inizializzazione di derivativeValues
 %calcolo dei valori usando l'algoritmo di Horner
 for i = n:-1:1  %da n a 1 scalando di -1
    derivativeValues = derivativeValues .* (xx - xi(ceil(i / 2))) + yy;
    yy = yy.*(xx- xi(ceil(i/2))) + diffDiv(i);
 end
 end