% Definizione del vettore x con linspace per includere il punto 4/3
x = linspace(1, 5/3, 100001);

% Definizione della funzione f(x)
f = @(x) 1 + x.^2 + log(abs(3*(1 - x) + 1))/80;

% Calcolo del vettore dei valori di f(x)
y = f(x);

% Grafico della funzione
plot(x, y, 'LineWidth', 1.5);
xlabel('x');
ylabel('f(x)');
title('Grafico di f(x)');
grid on;

% Trova il minimo
[min_value, min_index] = min(y);
min_x = x(min_index);

% Visualizza il minimo trovato
fprintf('Il minimo della funzione si trova in x = %.5f con valore f(x) = %.5f\n', min_x, min_value);