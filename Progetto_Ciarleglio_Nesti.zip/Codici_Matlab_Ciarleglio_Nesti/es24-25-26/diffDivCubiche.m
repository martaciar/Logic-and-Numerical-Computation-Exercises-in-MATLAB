function diffDiv = diffDivCubiche(x, y, grado)
    % diffDiv = diffDivCubiche(x, y, grado)
    % 
    % La function calcola le differenze divise per la spline cubica 
    %
    % Input:
    % x: Vettore delle ascisse
    % y: Vettore delle ordinate
    % grado: Numero di livelli di differenze divise da calcolare(it-1)
    % Output:
    % diffDiv: Vettore delle differenze divise
    %
    % Val: 21/10/2024
    n = length(x);
    if length(y) ~= (n)
        error('Argomenti errati');
    end
    diffDiv = y;
    for j=1:grado-1
        for i = n:-1:j+1
            diffDiv(i) = (diffDiv(i) - diffDiv(i-1))/(x(i) - x(i-j));
        end
    end
    diffDiv = diffDiv(1, grado:n);
end
