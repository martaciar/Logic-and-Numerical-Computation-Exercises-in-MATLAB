f = @(x) 1./(1 + x.^2);
x = linspace(-10, 10, 10001);
yf = f(x);
erroreSplineNat = zeros(1, numel(4:4:800));
erroreSplineNaK = zeros(1, numel(4:4:800));
xi=zeros;
for n = 4:4:800
    for i=0:n
        xi(i+1) = -10 + i*20/n;
    end
    yNat = spline0(xi, f(xi), x);
    yNaK = spline(xi, f(xi), x);
    erroreSplineNat(n/4) = norm(yf - yNat, inf);
    erroreSplineNaK(n/4) = norm(yf - yNaK, inf);
end
h = 20 ./ (4:4:800); %ampiezze

figure(1);
loglog(h, erroreSplineNat, 'm');
xlabel('h=20/n');
ylabel('Errore');
title('Errore di approssimazione con spline cubica naturale interpolante');

figure(2);
loglog(h, erroreSplineNaK, 'c');
xlabel('h=20/n');
ylabel('Errore');
title('Errore di approssimazione con spline cubica not-a-knot interpolante');