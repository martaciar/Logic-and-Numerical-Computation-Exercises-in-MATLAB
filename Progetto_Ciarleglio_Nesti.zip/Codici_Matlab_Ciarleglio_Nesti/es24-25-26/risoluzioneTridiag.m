function x = risoluzioneTridiag(mainDiag, lowerDiag, upperDiag, x)
    % x = risoluzioneTridiag(mainDiag, lowerDiag, upperDiag, rhs)
    %
    % Funzione che risolve un sistema tridiagonale della forma:
    %
    % lowerDiag(i) * x(i-1) + mainDiag(i) * x(i) + upperDiag(i) * x(i+1) = rhs(i), i = 1...n
    %
    % con x(0) = x(n+1) = 0.
    %
    % Input:
    % - mainDiag: Vettore dei coefficienti della diagonale principale
    % - lowerDiag: Vettore dei coefficienti della diagonale inferiore
    % - upperDiag: Vettore dei coefficienti della diagonale superiore
    % - x: Vettore dei termini noti del sistema
    %
    % Output:
    % - x: Soluzione del sistema tridiagonale (viene sovrascritto il vettore
    % dei termini noti)
    %
    % Val: 21/10/2024
    n = length(mainDiag);
    for i = 1:n-1
        lowerDiag(i) = lowerDiag(i)/mainDiag(i);
        mainDiag(i+1) = mainDiag(i+1) - lowerDiag(i)*upperDiag(i);
        x(i+1) = x(i+1) - lowerDiag(i)*x(i);
    end
    x(n) = x(n)/mainDiag(n);
    for i = n-1:-1:1
        x(i) = (x(i) - upperDiag(i)*x(i+1))/mainDiag(i);
    end
end