function YQ = spline0(X, Y, XQ)
    % YQ = spline0(X, Y, XQ)
    %
    % La function calcola la spline cubica naturale interpolante 
    %
    % Input:
    % X: Ascisse di interpolazione
    % Y: Valori assunti dalla funzione sulle ascisse X
    % XQ: Vettore delle ascisse dove si calcola il valore della spline 
    %
    % Output:
    % YQ: Valori della spline cubica naturale
    %
    % Val: 21/10/2024
    if nargin < 3 
        error('Argomenti insufficienti');
    end
    n = length(X)-1;
    if length(Y) ~= (n+1)
        error('Argomenti errati');
    end
    %calcolo ampiezza sottointervalli tra ogni coppia di ascisse
    h(1:n) = X(2:n+1) - X(1:n);
    %coefficienti e vettore per costruire matrice tridiagonale
    phi = h(2:n-1)./(h(2:n-1) + h(3:n)); 
    csi = h(2:n-1)./(h(1:n-2) + h(2:n-1)); 
    a(1:n-1) = 2;
    %calcolo differenze divise di terzo ordine su Y e X vettori
    diffdiv = diffDivCubiche(X, Y, 3);
    %Risoluzione sistema
    m = risoluzioneTridiag(a, phi, csi, 6*diffdiv); %ottengo derivate seconde
    m = [0, m, 0];
    YQ = zeros(size(XQ));
    j = 1;
    for i=2:n+1
        ri = Y(i-1) - (h(i-1)^2)/6 * (m(i-1));%costante d'interpolazione associata a i-1
        qi = (Y(i) - Y(i-1))/h(i-1) - h(i-1)/6*(m(i) - m(i-1)); %pendenza locale di ogni segmento
        while j <= length(XQ) && XQ(j) <= X(i)
            YQ(j) = ((XQ(j) - X(i-1))^3 * m(i) + (X(i) - XQ(j))^3 * m(i-1))/(6*h(i-1)) + qi*(XQ(j) - X(i-1)) + ri;
            j = j+1;
        end
    end
end