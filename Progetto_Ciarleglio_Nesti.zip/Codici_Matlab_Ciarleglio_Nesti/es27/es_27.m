rng(0)
xi=linspace(0,2*pi,101);
yi=sin(xi)+rand(size(xi))*.05;
V=zeros([101,4]);
for i=1:length(xi)
    for j=1:4
        V(i,j)=xi(i).^(j-1);
    end
end
yi=yi.';
a=miaqr(V, yi);
disp('Risultato del sistema Va=yi:')
disp(a);
disp('Tali risultati rappresentano i coefficienti del polinomio di approssimazione ai minimi quadrati di grado 3');
y2=a(1)+a(2)*xi+a(3)*xi.^2+a(4)*xi.^3;
figure(1);
plot(xi, yi,'ko', "MarkerSize", 2, "LineWIdth", 2);
hold on;
plot(xi, y2,'b-', "MarkerSize", 2, "LineWIdth", 2);
title("Polinomio di approssimazione ai minimi quadrati di grado 3");
xlabel("x");
ylabel("y");
axis([0 2*pi -1.5 1.5]);
grid on;