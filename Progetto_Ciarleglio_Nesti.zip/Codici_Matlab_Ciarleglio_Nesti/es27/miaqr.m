function [x, nr] = miaqr(A, b)
    % miaqr - Risolve il sistema lineare Ax = b nel senso dei minimi quadrati
    % usando la fattorizzazione QR
    %
    % Sintassi:
    %   [x, nr] = miaqr(A, b)
    %
    % Input:
    %   A = Matrice m x n con m >= n e rank(A) = n
    %   b = Vettore dei termini noti (lunghezza m)
    %
    % Output:
    %   x = Soluzione del sistema
    %   nr = Norma del vettore residuo
    
    [m, n] = size(A);
    
    % Controllo della dimensione del vettore b
    if length(b) ~= m
        error('Il vettore b deve avere la stessa lunghezza del numero di righe di A.');
    end
    
    % Algoritmo di fattorizzazione QR
    for i = 1:n
        % Calcolo della norma della colonna
        alfa = norm(A(i:m, i));
        
        % Controllo del rango
        if alfa == 0
            error('La matrice A non ha rango massimo.');
        end
        
        % Cambia il segno di alfa se necessario
        if A(i, i) >= 0
            alfa = -alfa;
        end
        
        % Creazione del vettore di Householder
        v1 = A(i, i) - alfa;
        A(i, i) = alfa;
        A(i+1:m, i) = A(i+1:m, i) / v1;
        beta = -v1 / alfa;
        
        % Aggiornamento di A e b
        A(i:m, i+1:n) = A(i:m, i+1:n) - beta * ([1; A(i+1:m, i)] * ([1 A(i+1:m, i)'] * A(i:m, i+1:n)));
        b(i:m) = b(i:m) - beta * ([1; A(i+1:m, i)] * ([1 A(i+1:m, i)'] * b(i:m)));
    end
    
    % Risoluzione del sistema triangolare superiore
    x = b(:);
    for i = n:-1:1
        x(i) = x(i) / A(i, i);
        x(1:i-1) = x(1:i-1) - A(1:i-1, i) * x(i);
    end
    
    % Calcolo della norma del residuo
    nr = norm(b(n+1:m), 2);
    
    % Restituisce solo i primi n elementi
    x = x(1:n);
    return
end

