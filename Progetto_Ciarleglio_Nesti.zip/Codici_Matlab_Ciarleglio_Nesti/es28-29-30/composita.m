function [If, err] = composita(fun, a, b, k, n)
    % [If, err] = composita(fun, a, b, k, n)
    %
    % Funzione che calcola l'approssimazione di un integrale attraverso la  
    % formula composita di Newton-Cotes di grado k su n+1 ascisse equidistanti 
    % (con n multiplo pari di k), restituendo una stima dell'errore di
    % quadratura.
    %
    % Input:
    % fun: Funzione integranda (che accetta input vettoriali)
    % [a,b]: Intervallo di integrazione 
    % k: Grado di una formula di Newton-Cotes (k>0)
    % n: Ascisse equidistanti con proprietà sopra definite
    %
    % Output:
    % If: Approssimazione dell'integrale
    % err: Stima dell'errore di quadratura
    %
    % Val: 26/10/2024
    if k < 1
        error('Grado inserito errato.');
    end
    if (mod(n,k)~=0||mod(n,2)~=0)
        error('Grado inserito errato.')
    end
    if a > b
        error('Intervallo errato.');
    end
    pesi = pesiNC(k);
    h = (b - a)/k;
    n2 = k;
    x = linspace(a, b, n+1);
    fx = feval(fun, x);
    If = h*sum(fx(1:k+1))*pesi(1:k+1);
    for i=1:n+1
         n2 = n2 * 2;
         h = (b - a) / n2;
         x = linspace(a, b, n2+1);
         fx(1:2:n2+1) = fx(1:n2/2 + 1);
         fx(2:2:n2) = feval(fun, x(2:2:n2));
         If2 = 0;
         for j=1:k+1
            If2 = If2 + h*sum(fx(j:k:n2))*pesi(j);
         end
         If2 = If2 + h*fx(n2+1)*pesi(k+1);
         err = abs(If2-If)/(2^(k+2) - 1);
         If = If2;
    end 
end