Pesi1=pesiNC(1);
Pesi2=pesiNC(2);
Pesi3=pesiNC(3);
Pesi4=pesiNC(4);
Pesi5=pesiNC(5);
Pesi6=pesiNC(6);
Pesi7=pesiNC(7);
Pesi9=pesiNC(9);
Pesi1=rats(Pesi1);
Pesi2=rats(Pesi2);
Pesi3=rats(Pesi3);
Pesi4=rats(Pesi4);
Pesi5=rats(Pesi5);
Pesi6=rats(Pesi6);
Pesi7=rats(Pesi7);
Pesi9=rats(Pesi9);


maxRows = max([size(Pesi1,1), size(Pesi2,1), size(Pesi3,1), size(Pesi4,1), ...
    size(Pesi5,1), size(Pesi6,1), size(Pesi7,1), size(Pesi9,1)]);

Pesi1 = [cellstr(Pesi1); repmat(' ', maxRows-size(Pesi1,1), 1)];
Pesi2 = [cellstr(Pesi2); repmat(' ', maxRows-size(Pesi2,1), 1)];
Pesi3 = [cellstr(Pesi3); repmat(' ', maxRows-size(Pesi3,1), 1)];
Pesi4 = [cellstr(Pesi4); repmat(' ', maxRows-size(Pesi4,1), 1)];
Pesi5 = [cellstr(Pesi5); repmat(' ', maxRows-size(Pesi5,1), 1)];
Pesi6 = [cellstr(Pesi6); repmat(' ', maxRows-size(Pesi6,1), 1)];
Pesi7 = [cellstr(Pesi7); repmat(' ', maxRows-size(Pesi7,1), 1)];
Pesi9 = [cellstr(Pesi9); repmat(' ', maxRows-size(Pesi9,1), 1)];

Ris1=table(Pesi1);
Ris2=table(Pesi2);
Ris3=table(Pesi3);
Ris4=table(Pesi4);
Ris5=table(Pesi5);
Ris6=table(Pesi6);
Ris7=table(Pesi7);
Ris9=table(Pesi9);
disp("Valori dei pesi:")
disp("Pesi 1");
disp(Pesi1);
disp("Pesi 2");
disp(Pesi2);
disp("Pesi 3");
disp(Pesi3);
disp("Pesi 4");
disp(Pesi4);
disp("Pesi 5");
disp(Pesi5);
disp("Pesi 6");
disp(Pesi6);
disp("Pesi 7");
disp(Pesi7);
disp("Pesi 9");
disp(Pesi9);
