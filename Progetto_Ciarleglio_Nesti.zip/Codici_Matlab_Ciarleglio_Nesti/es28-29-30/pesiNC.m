function peso = pesiNC(n)
    % peso = pesiNC(n)
    %
    % Funzione che restituisce i pesi della quadratura della formula di 
    % Newton-Cotes di grado n
    %
    % Input:
    % n: Grado della formula di Newton Cotes (0<n<8 o n=9)
    %
    % Output:
    % peso: Pesi della quadratura
    %
    % Val: 26/10/2024
    if n <= 0 || n >= 10 || n == 8
        error('Grado della funzione errato.');
    end
    peso = zeros(1, n+1);
    for i=0:n
         d = i-[0:i-1 i+1:n];
         den = prod(d);
         a = poly([0:i-1 i+1:n]);
         a = [a./((n+1):-1:1) 0];
         num = polyval(a, n);
         peso(i+1) = num / den;
    end
end