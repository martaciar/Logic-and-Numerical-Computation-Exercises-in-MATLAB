function [radice,iterazioni] = bisezione(f, a, b, tol, itmax)
    % [radice,iterazioni] = bisezione(f, a, b, tol, itmax)
    %
    % Funzione che approssima la radice di f(x) tramite il metodo di bisezione 
    %
    % Input:
    % f = identificatore della function che implementa f(x)
    % a,b = estremi dell'intervallo 
    % tol = accuratezza richiesta (default=10^-6)
    % itmax = numero massimo di iterazioni (default = 
    %         ceil(log2(b-a)-log2(tol))
    % 
    % Output:
    % radice = approssimazione della soluzione
    % iterazioni = numero di iterazioni fatte per trovare la soluzione
    % 
    % Val: 30/09/2024
    if nargin<3
        error('Numero di argomenti errato');
    end
    if nargin<4
        tol=1e-6;
    end
    if nargin<5
        itmax=ceil(log2(b-a)-log2(tol));
    end
    if tol<=0
        error('Tolleranza non valida.');
    end
    if itmax<=0
        error('Numero iterazioni massime non valido.');
    end
    
    iterazioni=1;
    radice=(a+b)/2;
    fa=feval(f,a);
    fb=feval(f,b);
    fx=feval(f,radice);

    if(fa*fb>0)
        error('Intervallo non valido, le ipotesi non verificano il teorema degli zeri');
    end
    if(fa==0)
        radice=a;
        return
    end
    if(fb==0)
        radice=b;
        return
    end

    while(abs(fx)>tol*abs((fb-fa)/(b-a)) && iterazioni<maxIter)
        if(fx*fa<0)
            b=radice;
            fb=fx;
        else
            a=radice;
            fa=fx;
        end
        radice=(a+b)/2;
        fx=feval(f,radice);
        iterazioni=iterazioni+1;
    end
    fprintf('La radice è %.15f ed `e stata ottenuta con %d iterazioni ', radice,iterazioni)
end