function [radice,iterazioni] = newton(f, df, x0, tol, itmax)
    % [radice,iterazioni] = newton(f, df, x0, tol, itmax)
    %
    % Funzione che approssima la radice di f(x) tramite il metodo di Newton.
    %
    % Input:
    % f = Identificatore della function che implementa f(x)
    % df = Identificatore della function che implementa f'(x)
    % x0 = Punto iniziale
    % tol = Accuratezza richiesta (default=10^-6)
    % itmax = Numero massimo di iterazioni (default = 10^3)
    %
    % Output:
    % radice = Approssimazione della soluzione
    % iterazioni= Numero di iterazioni fatte per trovare la soluzione
    %
    % Val: 30/09/2024
    if nargin < 3
        error('Numero di argomenti non valido.');
    end
    if nargin < 4
        tol = 1e-6; % Tolleranza predefinita
    end
    if nargin < 5
        itmax = 100; % Numero massimo di iterazioni predefinito
    end
    if tol<=0
        error('Tolleranza non valida.');
    end
    if itmax<=0
        error('Numero di iterazioni massime non valido.');
    end
    iterazioni=1;
    fx = feval(f, x0);
    der = feval(df, x0);
    if der==0
        error('Il metodo non converge, la derivata della funzione è zero.');
    end

    %Metodo di Newton
    radice=x0-(fx/der);
    while(iterazioni<itmax) && (abs(radice-x0)>tol*(1+abs(radice)))
        iterazioni=iterazioni+1;
        x0=radice;
        fx= feval(f,x0);
        der=feval(df,x0);
        if abs(der)<eps
            error('Derivata nulla, il metodo non converge.');
        end
        radice=x0-(fx/der);
    end
    if(abs(radice-x0)>tol*(1+abs(radice)))
        error('Risultato non ottenibile.');
    end
    fprintf('La radice è %.15f ed è stata ottenuta con %d iterazioni', radice,iterazioni);
end