function [radice,iterazioni] = newtonModificato(f,df,x0,m,tol,maxIter)
%[radice,iterazione]=newton(f,df,x0,m,tol maxIter)
%   Funzione che approssima radice tramite metodo di newton modificato.
%   Input:
%   f: funzione oggetto del calcolo della radice
%   df: derivata della f
%   x0: punto di partenza
%   m: molteplicità della radice della funzione f
%   tol: accuratezza richiesta
%   maxIter: Iterazioni massime permesse
if nargin < 4
    error('Numero di argomenti non valido');
end
if nargin < 5
    tol = 1e-6;  % Tolleranza predefinita
end
if nargin < 6
    maxIter = 100;  % Numero massimo di iterazioni predefinito
end
if tol<=0
    error('Tolleranza non permessa');
end
if(maxIter<=0)
    error('maxIter non permessa');
end
iterazioni=1;
fx = feval(f, x0);
der = feval(df, x0);
if(der==0)
    error('Il metodo non converge, la derivata della funzione è zero');
end
radice=x0-m*(fx/der);
while(iterazioni<maxIter) && (abs(radice-x0)>tol*(1+abs(radice)))
    iterazioni=iterazioni+1;
    x0=radice;
    fx= feval(f,x0);
    der=feval(df,x0);
    if der==0 %(abs(der)<eps)
        error('Derivata nulla, il metodo non converge');
    end
    radice=x0-m*(fx/der);
end
if(abs(radice-x0)>tol*(1+abs(radice)))
    error(['Risultato non ottenibile. Riprovare con più iterazioni potrebbe ' ...
        'risolvere il problema']);
end
fprintf('La radice del problema è %.6f ottenuta con %d iterazioni',radice,iterazioni);
end