function [radice, iterazioni] = secanti(f, x0, x1, tol, itmax)
    % [radice,iterazioni] = secanti(f, x0, x1, tol, itmax)
    %
    % Funzione che approssima la radice di f(x) tramite il metodo delle secanti.
    %
    % Input:
    % f = Identificatore della function che implementa f(x)
    % x0,x1 = Estremi dell’intervallo
    % tol = Accuratezza richiesta (default=10^-6)
    % itmax = Numero massimo di iterazioni (default = 10^3)
    %
    % Output:
    % radice = Approssimazione della soluzione
    % iterazioni = Numero di iterazioni fatte per trovare la soluzione
    %
    % Val: 01/10/2024
    if nargin < 3
        error('Numero di argomenti non valido.');
    end
    if nargin == 3
        tol = 1e-6; % Tolleranza predefinita
        itmax = 100;
    end
    if nargin == 4
        itmax = 100; % Numero massimo di iterazioni predefinito
    end
    if tol <= 0
        error('Tolleranza non valida, deve essere positiva.');
    end
    if itmax <= 0
        error('maxIter deve essere un numero positivo.');
    end

    iterazioni = 0;
    fx0 = feval(f, x0);
    fx1 = feval(f, x1);
    if fx0 == fx1
        error('Errore: i valori iniziali danno lo stesso valore di funzione. Il metodo non converge.');
    end

    radice=x1;
    while (iterazioni < itmax) && (abs(x1 - x0) > tol*(1 + abs(x1)))
        iterazioni = iterazioni + 1;
        radice = (fx1 * x0 - fx0 *x1) / (fx1 - fx0);

        %aggiornamento valori per prossima iterazione
        x0 = x1;
        fx0 = fx1;
        x1 = radice;
        fx1 = feval(f, x1);
        if abs(fx1 - fx0) < eps
            error('Divisione per zero, il metodo non converge.');
        end
    end

    if abs(x1 - x0) > tol*(1 + abs(x1))
        error('Il metodo non ha raggiunto la convergenza dopo il numero massimo di iterazioni.');
    end
    fprintf('La radice del problema è %.6f ottenuta con %d iterazioni', radice,iterazioni);
end