A=[1 1; 1 2; 1 3];
b=[1; 2; 2];
A2=[2 0; 1 2; 1 1];
b2=[4; 6; 5];
A3=[1 2 3; 4 5 6];
b3=[1; 2];

disp('Esempio 1');
disp('Matrice A:');
disp(A);
disp('Vettore b:');
disp(b);
disp('Risultato:');
[x, nr]=miaqr(A, b);
disp(x)
disp('Con norma:')
disp(nr);

disp('Esempio 2');
disp('Matrice A:');
disp(A2);
disp('Vettore b:');
disp(b2);
disp('Risultato:');
[x2, nr2]=miaqr(A2, b2);
disp(x2)
disp('Con norma:')
disp(nr2);

disp('Esempio 3');
disp('Matrice A:');
disp(A3);
disp('Vettore b:');
disp(b3);
disp('Risultato:');
[x3, nr3]=miaqr(A3, b3);
disp(x3)
disp('Con norma:')
disp(nr3);