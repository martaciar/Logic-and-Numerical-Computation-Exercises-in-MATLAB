ris=zeros(15);
for i=1:15
    A=newTable(i);
    b=newVector(i);
    x=mialu(A,b);
    for j=1:i
        ris(i,j)=x(j);
    end
end

for i=1:15
    for j=1:15
        if i>=j
            ris(i,j)=round(ris(i,j),5);
        end
    end
end

disp(ris);
