x=zeros(100);
A=[];
for i=1:100
    A=newTableSDP(i);
    A=mialdlt(A);
    for j=1:i
        for k=1:i
            if j==k
                x(i,j)=A(j,k);
            end
        end
    end
end

for i=1:100
    A=newTableSDP(i);
    A=mialdlt(A);
    elementi_diagonali=diag(A);
    indici=(1:numel(elementi_diagonali))';
    plot(indici, elementi_diagonali, 'ko-','MarkerSize', 2);
    hold on;
end
xlabel('Indice');
ylabel('Elemento Diagonale');
title('Grafico elementi diagonali');