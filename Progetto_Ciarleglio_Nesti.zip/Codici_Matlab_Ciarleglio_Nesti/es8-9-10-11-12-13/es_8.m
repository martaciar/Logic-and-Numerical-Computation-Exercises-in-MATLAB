A=[3 -2 1; 2 1 -1; 1 1 1];
b=[1; 0; 3];
A2=[4 -1 2; 3 2 -1; -1 1 3];
b2=[9; -2; 4];
A3=[2 4 2; 1 2 1; 0 0 0];
b3=[8; 4; 0];

disp('Esempio 1');
disp('Matrice A:');
disp(A);
disp('Vettore b:');
disp(b);
disp('Risultato:');
x=mialu(A, b);
disp(x);

disp('Esempio 2');
disp('Matrice A:');
disp(A2);
disp('Vettore b:');
disp(b2);
disp('Risultato:');
x2=mialu(A2, b2);
disp(x2);

disp('Esempio 3');
disp('Matrice A:');
disp(A3);
disp('Vettore b:');
disp(b3);
disp('Risultato:');
x3=mialu(A3, b3);
disp(x3);