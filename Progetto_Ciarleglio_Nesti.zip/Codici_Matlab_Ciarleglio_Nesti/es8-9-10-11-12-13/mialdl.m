function x = mialdl(A, b)
    % x = mialdl(A, b)
    % Funzione che risolve il sistema lineare Ax = b usando la fattorizzazione LDL^T
    %
    % Input:
    %   A = Matrice simmetrica definita positiva
    %   b = Vettore dei termini noti
    %
    % Output:
    %   x = Soluzione del sistema lineare
    % 
    % Val: 03/10/2024
    
    % Dimensione della matrice
    [m, n] = size(A);
    
    % Controllo che A sia quadrata
    if m ~= n
        error('La matrice deve essere quadrata.');
    end
    
    % Controllo compatibilità dimensioni b
    if n ~= length(b)
        error('Il vettore b deve avere dimensione compatibile con A.');
    end
    
    % Controllo che la matrice sia SDP
    if A(1, 1) <= 0
        error('La matrice non è definita positiva.');
    end
    
    % Fattorizzazione LDL^T
    A(2:n,1) = A(2:n,1)/A(1,1);
    for j = 2:n
        v = (A(j,1:j-1).').* diag(A(1:j-1,1:j-1));
        A(j,j) = A(j,j) - A(j,1:j-1)*v;
        if A(j,j)<=0
            error('La matrice non è definita positiva')
        end
        A(j+1:n,j) = (A(j+1:n,j)-A(j+1:n,1:j-1)*v)/A(j,j);
    end
    
    % Risoluzione del sistema
    x = b(:);
    d = diag(A);
    if any(d <= 0)
        error('La matrice non è definita positiva.');
    end
    
    % Risoluzione della prima parte
    for i = 2:n
        x(i:n) = x(i:n) - A(i:n, i-1) * x(i-1);
    end
    
    % Divisione per la diagonale
    x = x ./ d;
    
    % Risoluzione della seconda parte
    for i = n:-1:2
        x(1:i-1) = x(1:i-1) - A(i, 1:i-1).' * x(i);
    end
end
