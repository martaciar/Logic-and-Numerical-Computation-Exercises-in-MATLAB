function [x,nr,pw] = miaqres13(A,b,w)
    %   Funzione che risolve l'esercizio 13 trovando il vettore residuo r del
    %   sistema Ax=b, successivamente calcola pw usando r e il vettore dei pesi w
    %   
    %   Input:
    %   A=matrice dei coefficienti
    %   b=vettore dei termini noti
    %   w=vettore dei pesi
    %   Output:
    %   x=radice ai minimi quadrati
    %   nr=norma del vettore residuo
    %   pw=Norma pesata del vettore residuo
    %
    % Val: 06/10/2024
    
    [m,~]=size(A);

    %Chiamata alla funzione miaqr
    [x, nr]=miaqr(A, b);
    r=A*x-b;
    pw=0;

    %Minimizzazione della norma pesata
    somma=sum(w);
    for i=1:m
        pw=pw+w(i)*r(i)^2;
    end
    pw=pw/somma;
    pw=sqrt(pw);
end