function A = newTable(i)
    % A = newTable(i)
    %
    % Funzione che crea la tabella di dimensione i x i con gli
    % elementi strettamente triangolari inferiori crescenti di 10^i e elementi
    % triangolari superiori uguali a 1 per l'es 11
    %
    % Input:
    % i = Dimensione matrice
    % 
    % Output:
    % A = Soluzione
    %
    A=zeros(i);
    for j=1:i
        for k=1:i
            if j>k
                A(j,k)=10^(j-k);
            else
                A(j,k)=1;
            end
        end
    end
    return 
end