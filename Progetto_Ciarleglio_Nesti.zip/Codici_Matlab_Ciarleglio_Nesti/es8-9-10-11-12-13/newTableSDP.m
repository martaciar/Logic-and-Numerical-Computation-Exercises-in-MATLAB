function A = newTableSDP(i)
% A = newTableSDP(i)
%
% Funzione che crea la tabella simmetrica definita positiva
% di dimensione i x i con elementi diagonali uguali ad i e i restanti 
% uguali a -1
%
% Input:
% i = Dimensione matrice
% 
% Output:
% A = Soluzione
%
if i<=0
    error('Dimensione errata');
end 
A=zeros(i);
for j=1:i
    for k=1:i
        if j==k
            A(j,k)=i;
        else
            A(j,k)=-1;
        end
    end
end