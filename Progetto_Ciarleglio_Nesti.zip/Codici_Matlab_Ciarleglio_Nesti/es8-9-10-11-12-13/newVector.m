function x = newVector(i)
    % x = newVector(i)
    %
    % Funzione che crea il vettore  
    %
    % Input:
    % i = Dimensione vettore
    % 
    % Output:
    % A = Soluzione
    %
    x = zeros(1,i);
    for j=1:i
        x(j)=i-j+(((10^j)-1)/9);
    end
    return 
end